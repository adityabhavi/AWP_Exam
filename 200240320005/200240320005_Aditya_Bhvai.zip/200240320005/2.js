

function submit(){
   // let uname = sub.parentElement.parentElement.parentElement.children[0].children[1].children[0].value;

    let uname = document.getElementById("unamein").value;

    let pass = document.getElementById("passin").value;

    let email = document.getElementById("emailin").value;

  //  let newElement = document.getElementById("information").cloneNode(true);

    
    let pname = document.getElementById("puname");

    pname.innerHTML=uname;

    let ppass = document.getElementById("ppass");

    ppass.innerHTML=pass;

    let pemail = document.getElementById("pemail");

    pemail.innerHTML=email;

    document.getElementById("unamein").value="";

    document.getElementById("passin").value="";

    document.getElementById("emailin").value="";



}